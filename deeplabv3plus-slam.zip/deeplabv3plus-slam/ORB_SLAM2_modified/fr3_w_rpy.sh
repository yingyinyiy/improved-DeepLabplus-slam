./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUM3.yaml /home/dxy/Data/rgbd_dataset_freiburg3_walking_rpy /home/dxy/Data/rgbd_dataset_freiburg3_walking_rpy/associations.txt

