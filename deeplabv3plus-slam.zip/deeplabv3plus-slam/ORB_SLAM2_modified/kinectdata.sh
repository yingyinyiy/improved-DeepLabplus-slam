./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUM3.yaml /home/dxy/Data/kinectdata /home/dxy/Data/kinectdata/associations.txt

