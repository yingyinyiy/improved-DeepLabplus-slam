./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUM3.yaml /home/dxy/Data/rgbd_dataset_freiburg3_sitting_xyz /home/dxy/Data/rgbd_dataset_freiburg3_sitting_xyz/associations.txt

